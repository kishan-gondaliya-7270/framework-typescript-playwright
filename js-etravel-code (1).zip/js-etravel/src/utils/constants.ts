export enum URLS {
  FLIGHT_NETWORK = 'https://www.flightnetwork.com',
  FLIGHT_NETWORK_RESULT = 'https://www.flightnetwork.com/rf/result'
}
