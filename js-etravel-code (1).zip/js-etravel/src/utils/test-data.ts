export const flightSearchData = {
  from: 'Ahmedabad',
  to: 'Pune',
  date: '20 $', 
  full_date: '2024-06-20'
}

export const flightAirlineOption = {
  indigo: 'IndiGo'
}
